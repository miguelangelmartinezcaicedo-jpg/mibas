import pandas as pd
import matplotlib.pyplot as plt

# Datos de departamentos
data = {
    'Departamento': ['Bogotá', 'Antioquia', 'Valle', 'Atlántico', 'Cundinamarca', 'Santander'],
    'Poblacion': [8000000, 6500000, 4800000, 2700000, 3200000, 2200000],
    'Colegios': [1250, 980, 720, 450, 520, 380]
}

df = pd.DataFrame(data)
print(df)

# Gráfica 1 - Barras
df.plot(kind='bar', x='Departamento', y='Poblacion', color='skyblue', figsize=(8,5))
plt.title('Población por Departamento')
plt.ylabel('Habitantes')
plt.xticks(rotation=45)
plt.grid(True)
plt.show()

# Gráfica 2 - Dispersión
df.plot(kind='scatter', x='Colegios', y='Poblacion', color='green', s=80, figsize=(8,5))
plt.title('Colegios vs Población')
plt.grid(True)
plt.show()

# Gráfica 3 - Pastel
df.plot(kind='pie', y='Poblacion', labels=df['Departamento'], autopct='%1.1f%%', figsize=(8,8))
plt.title('Distribución de Población')
plt.ylabel('')
plt.show()

print("¡Listo! Se crearon las 3 gráficas")